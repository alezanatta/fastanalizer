from fastanalizer import pyfasta
from fastanalizer import geral
from fastanalizer import domainsearch
from fastanalizer import pdomain
from fastanalizer import align
from fastanalizer import tree
from fastanalizer.fastanalizer import main